#!/bin/sh
java -Xms128m -Xmx512m -splash:cube.png -cp ./QBrowserV2_Neo.jar:./jide-oss-2.6.2.jar:./imq.jar:./jms.jar:./imqadmin_ja.jar:./imqadmin.jar:./imqutil_ja.jar:./imqutil.jar:./imqjmx.jar:./imqjmx_ja.jar com.qbrowser.QBrowserV2
