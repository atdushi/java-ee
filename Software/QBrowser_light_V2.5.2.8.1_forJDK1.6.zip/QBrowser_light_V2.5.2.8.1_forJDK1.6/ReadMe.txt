#QBrowserV2 is a tool that developed by open source project for queue data administration/testing.
Please make sure that no warranty would be provided with this tool (GPLv2).
Please visit the site bellow, if you want to see souce codes or other information regarding this project.
http://sourceforge.net/projects/qbrowserv2/

QBrowserV2.5.1.3 is tested with ;


OpenMQ 4.4 (tested with beta version)
OpenMQ 4.3 / Sun Java System Message Queue 4.3
OpenMQ 4.2 / Sun Java System Message Queue 4.2
OpenMQ 4.1 / Sun Java System Message Queue 4.1
OpenMQ 4.0 / Sun Java System Message Queue 4.0
Sun Java System MessageQueue 3.7


WebLogic Server 8.x
WebLogic Server 9.x
WebLogic Server 10g
WebLogic Server 11g